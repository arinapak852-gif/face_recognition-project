import tkinter as tk
import cv2
from PIL import Image, ImageTk
import os
import subprocess
from datetime import datetime
import util

class App:
    def __init__(self):
        # main window 
        self.main_window = tk.Tk()
        self.main_window.geometry("1200x520+350+100")
        self.main_window.title("Face Attendance System")
        
        # data and login
        self.db_dir = './db'
        if not os.path.exists(self.db_dir):
            os.mkdir(self.db_dir)
        
        self.log_path = './log.txt'
        
        # button login
        self.login_button_main_window = util.get_button(
            self.main_window, 
            'Login', 
            'red',
            self.login
        )
        self.login_button_main_window.place(x=750, y=300)
        
        # button new user 
        self.register_new_user_button_main_window = util.get_button(
            self.main_window,
            'Register New User',
            'blue',
            self.register_new_user,
            fg='black'
        )
        self.register_new_user_button_main_window.place(x=750, y=400)
        
        # webcam
        self.webcam_label = util.get_img_label(self.main_window)
        self.webcam_label.place(x=10, y=0, width=700, height=500)
        
        # add webcam
        self.add_webcam(self.webcam_label)
    
    def add_webcam(self, label):

        if 'cap' not in self.__dict__:
            self.cap = cv2.VideoCapture(0)  
        
        self._label = label
        self.process_webcam()
    
    def process_webcam(self):
        
        ret, frame = self.cap.read()
        
        if ret:
            self.most_recent_capture_arr = frame
            img_ = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            self.most_recent_capture_pil = Image.fromarray(img_)
            imgtk = ImageTk.PhotoImage(image=self.most_recent_capture_pil)
            self._label.imgtk = imgtk
            self._label.configure(image=imgtk)
        
       
        self._label.after(20, self.process_webcam)
    
    def login(self):
        
        print("Login button clicked")
        
    def register_new_user(self):
        """Функция регистрации нового пользователя"""
        print("Register button clicked")
        
    
    def start(self):
        """Запуск приложения"""
        self.main_window.mainloop()

if __name__ == "__main__":
    app = App()
    app.start()